"""开发自测：用 AstrBot 桩跑通「蓝奏云链接提取（只读）」插件的完整业务逻辑。

运行方式（在插件目录下）::

    python _devtest/test_plugin.py

覆盖范围
--------
* 插件只注册了 3 个指令（file / 搜索 / 下载），**没有任何群文件上传事件处理器**
* 已彻底移除群文件索引层（``file_store`` / ``group_file_import`` 不存在）
* 蓝奏云只读清单：TTL 缓存、强制刷新、失败回退旧缓存
* 按文件名模糊搜索（归一化 + 子串）、按数字文件ID / 文件名定位
* ``/file list|search|download|lzrefresh|help`` 指令（含权限与群聊限制）
* 群内快捷指令「搜索」「下载」（含开关与私聊静默）
* 全部 Web API handler（overview / files / files/link / files/refresh）
* **蓝奏云 ``ShareInfo`` 只有链接 + 提取码** —— 卡片与接口都不得出现
  「短链接」「口令」这两行（那是百度网盘那套概念）
* 纯函数：human_size / numeric_id / normalize_name
"""

from __future__ import annotations

import asyncio
import inspect
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# 0) 安装桩（必须在导入插件之前）
# ---------------------------------------------------------------------------
# 把插件目录的**父目录**加入 sys.path，这样 `astrbot_plugin_group_file_manager`
# 才是一个可导入的包（无论从哪个目录运行测试）。
_PLUGIN_ROOT = Path(__file__).resolve().parent.parent
_PARENT = _PLUGIN_ROOT.parent
for _p in (str(_PARENT), str(_PLUGIN_ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from _devtest.astrbot_stubs import install_stubs  # noqa: E402

install_stubs()

from _devtest.astrbot_stubs import astrbot_api_event as stub_event  # noqa: E402
from _devtest.astrbot_stubs import astrbot_api_message_components as stub_comp  # noqa: E402
from _devtest.astrbot_stubs import astrbot_api_star as stub_star  # noqa: E402
from _devtest.astrbot_stubs import astrbot_api_web as stub_web  # noqa: E402

from astrbot_plugin_group_file_manager import file_utils, lanzou_store, main  # noqa: E402

# ---------------------------------------------------------------------------
# 测试框架
# ---------------------------------------------------------------------------
PASSED: list[str] = []
FAILED: list[tuple[str, str]] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        PASSED.append(name)
        print(f"  [PASS] {name}")
    else:
        FAILED.append((name, detail))
        print(f"  [FAIL] {name} :: {detail}")


def section(title: str) -> None:
    print(f"\n=== {title} ===")


# ---------------------------------------------------------------------------
# 假蓝奏云客户端
# ---------------------------------------------------------------------------
class FakeLanzou:
    """模拟 ``lanzou_store.LanzouClient`` 的两个只读接口。

    真实客户端只暴露 ``list_files`` / ``share_info``；这里保持一致，
    顺带记录调用次数，用于验证 TTL 缓存与强制刷新。
    """

    def __init__(
        self,
        files: list[dict] | None = None,
        shares: dict[int, dict] | None = None,
        *,
        fail_list: bool = False,
        fail_share: bool = False,
    ) -> None:
        self.files = files or []
        self.shares = shares or {}
        self.fail_list = fail_list
        self.fail_share = fail_share
        self.list_calls = 0
        self.share_calls: list[int] = []

    async def list_files(self, *, recursive: bool = True, max_depth: int = 3):
        self.list_calls += 1
        if self.fail_list:
            raise lanzou_store.LanzouError("模拟：读取清单失败")
        # 返回副本，避免插件改写喂进来的字面量
        return [dict(item) for item in self.files]

    async def share_info(self, fid: int) -> dict:
        self.share_calls.append(int(fid))
        if self.fail_share:
            raise lanzou_store.LanzouError("模拟：取分享链接失败")
        info = self.shares.get(int(fid))
        if not info:
            raise lanzou_store.LanzouError(f"模拟：没有 fid={fid} 的分享信息")
        return dict(info)


# ---------------------------------------------------------------------------
# 构造辅助
# ---------------------------------------------------------------------------
GROUP = "366376516"

SAMPLE_FILES = [
    {"fid": 111, "name": "朗朗 晴天.zip", "size": "35.1 M", "time": "2026-09-20"},
    {"fid": 222, "name": "报告2024.pdf", "size": "1.2 M", "time": "2026-09-26"},
    {"fid": 333, "name": "朗朗晴天.mp3", "size": "8.4 M", "time": "2026-09-22"},
]

SAMPLE_SHARES = {
    111: {"fid": 111, "url": "https://wwx.lanzou.com/iABC111", "pwd": "ab11", "name": "朗朗 晴天.zip"},
    222: {"fid": 222, "url": "https://wwx.lanzou.com/iABC222", "pwd": "", "name": "报告2024.pdf"},
    333: {"fid": 333, "url": "https://wwx.lanzou.com/iABC333", "pwd": "cd33", "name": "朗朗晴天.mp3"},
}


def make_plugin(**overrides):
    """构造一个「蓝奏云已启用且已配置」的插件实例 + 假客户端。"""
    config = {
        "quick_commands": True,
        "search_page_size": 5,
        "lanzou_enabled": True,
        "lanzou_cookie_ylogin": "88888",
        "lanzou_cookie_phpdisk_info": "abcdef%3D%3D",
        "lanzou_folder": "",
        "lanzou_recursive": True,
        "lanzou_cache_minutes": 30,
    }
    config.update(overrides)
    context = stub_star.Context()
    plugin = main.GroupFileManagerPlugin(context, config)
    return plugin, context


def attach_fake(plugin, fake: FakeLanzou) -> FakeLanzou:
    """把假客户端塞进插件的懒加载缓存位。"""
    plugin._lanzou = fake
    return fake


def make_command_event(
    text: str,
    group_id: str = GROUP,
    role: str = "admin",
    *,
    private: bool = False,
) -> stub_event.AstrMessageEvent:
    """构造指令事件（默认群聊 + 管理员）。"""
    if private:
        abm = stub_event.AstrBotMessage(
            type=stub_event.MessageType.FRIEND_MESSAGE,
            session_id="private-1",
            group_id="",
            sender=stub_event.MessageMember(user_id="20001", nickname="张三"),
            message=[],
            message_str=text,
        )
        return stub_event.AstrMessageEvent(abm, session_id="private-1", message_str=text, role=role)
    abm = stub_event.AstrBotMessage(
        type=stub_event.MessageType.GROUP_MESSAGE,
        session_id=group_id,
        group_id=group_id,
        sender=stub_event.MessageMember(user_id="20001", nickname="张三"),
        message=[],
        message_str=text,
        group=stub_event.Group(group_id=group_id, group_name="测试群"),
    )
    return stub_event.AstrMessageEvent(abm, session_id=group_id, message_str=text, role=role)


async def run_command(plugin, event, message_str: str) -> list:
    """走 AstrBot 真实的参数解析路径调用 /file 指令。"""
    params = stub_event._parse_command_params(
        main.GroupFileManagerPlugin.file_command,
        message_str,
    )
    if params is None:
        raise AssertionError(f"指令未匹配: {message_str}")
    results = []
    async for item in stub_event.call_handler(event, plugin.file_command, **params):
        results.append(item)
    return results


async def run_quick(plugin, unbound_handler, event, message_str: str) -> list:
    """走 AstrBot 真实的参数解析路径调用快捷指令（搜索 / 下载）。

    参数解析必须传**未绑定函数**（从类上取到的 function），否则签名里没有
    self，桩的「跳过 self 与 event」逻辑会把第一个真实参数也跳过。
    """
    params = stub_event._parse_command_params(unbound_handler, message_str)
    if params is None:
        raise AssertionError(f"指令未匹配: {message_str}")
    bound = unbound_handler.__get__(plugin, type(plugin))
    results = []
    async for item in stub_event.call_handler(event, bound, **params):
        results.append(item)
    return results


def plain_texts(results: list) -> list[str]:
    out = []
    for result in results:
        for comp in getattr(result, "chain", []) or []:
            if isinstance(comp, stub_comp.Plain):
                out.append(comp.text)
    return out


def joined(results: list) -> str:
    return "\n".join(plain_texts(results))


def make_request(pairs: list[tuple[str, str]] | None = None) -> stub_web._Request:
    req = stub_web._Request()
    if pairs:
        req.query = stub_web._MultiDict(pairs)
    return req


async def call_api(handler, pairs: list[tuple[str, str]] | None = None):
    """在绑定了 query 的请求上下文里调用 Web API handler。"""
    token = stub_web.set_request(make_request(pairs))
    try:
        return await handler()
    finally:
        stub_web.reset_request(token)


# ===========================================================================
# 各测试小节
# ===========================================================================
def test_no_group_file_layer() -> None:
    section("1. 群文件层已彻底移除")

    # 旧模块文件应当不存在
    for gone in ("file_store.py", "group_file_import.py", "clean_group.py"):
        check(f"{gone} 已删除", not (_PLUGIN_ROOT / gone).exists())

    # main 模块不再引用它们
    check("main 未导入 file_store", not hasattr(main, "file_store"))
    check("main 未导入 group_file_import", not hasattr(main, "group_file_import"))

    # 插件类没有任何群文件上传处理器
    handlers = [
        name
        for name in dir(main.GroupFileManagerPlugin)
        if "upload" in name.lower() or "index" in name.lower()
    ]
    check("插件类没有上传/索引处理器", handlers == [], f"发现: {handlers}")

    # 只注册了 3 个指令，且没有 event_message_type 处理器
    kinds = stub_event.registered_handlers
    names = sorted(h["name"] for h in kinds if h["kind"] == "command")
    check(
        "只注册了 file / 搜索 / 下载",
        set(names) == {"file", "搜索", "下载"},
        f"实际: {names}",
    )
    check(
        "没有 event_message_type 处理器（不识别群文件上传）",
        all(h["kind"] != "event_message_type" for h in kinds),
    )

    # 配置项里不再有群文件相关项
    for gone_key in ("enabled", "max_list_items", "allow_delete_by_non_admin", "import_enabled"):
        check(
            f"配置默认值不含 {gone_key}",
            gone_key not in main._DEFAULT_CONFIG,
        )


def test_register_metadata() -> None:
    section("2. 注册信息 / 版本号")

    args = main.GroupFileManagerPlugin._register_args
    check("插件名正确", args[0] == "astrbot_plugin_group_file_manager", f"{args[0]}")
    check("版本号为 3.0.0", args[3] == "3.0.0", f"{args[3]}")
    check(
        "描述声明不索引群文件",
        "不索引群文件" in args[2] or "不索引" in args[2],
        args[2],
    )


def test_file_utils() -> None:
    section("3. 纯函数 file_utils")

    check("human_size 0", file_utils.human_size(0) == "0 B")
    check("human_size 512", file_utils.human_size(512) == "512 B")
    check("human_size 2048", file_utils.human_size(2048) == "2.0 KB")
    check("human_size 非法值", file_utils.human_size("x") == "0 B")

    nid = file_utils.numeric_id("lz_111")
    check("numeric_id 稳定", file_utils.numeric_id("lz_111") == nid)
    check("numeric_id 纯数字", nid.isdigit(), nid)
    check("numeric_id 不超过 9 位", len(nid) <= 9, nid)
    check(
        "不同 fid 派生出不同 ID",
        file_utils.numeric_id("lz_111") != file_utils.numeric_id("lz_222"),
    )

    check(
        "normalize_name 抹平空格/下划线",
        file_utils.normalize_name("朗朗 晴天.zip") == file_utils.normalize_name("朗朗_晴天.zip"),
    )
    check(
        "normalize_name 抹平大小写",
        file_utils.normalize_name("ABC.pdf") == file_utils.normalize_name("abc.pdf"),
    )


def test_lanzou_configured() -> None:
    section("4. 蓝奏云配置判定（仅 Cookie 登录）")

    plugin, _ = make_plugin()
    check("Cookie 齐全 → 已配置", plugin._lanzou_configured() is True)

    disabled, _ = make_plugin(lanzou_enabled=False)
    check("未启用 → 未配置", disabled._lanzou_configured() is False)

    no_cred, _ = make_plugin(lanzou_cookie_ylogin="", lanzou_cookie_phpdisk_info="")
    check("启用但无 Cookie → 未配置", no_cred._lanzou_configured() is False)

    only_ylogin, _ = make_plugin(lanzou_cookie_phpdisk_info="")
    check("只填 ylogin → 未配置", only_ylogin._lanzou_configured() is False)

    # 账号密码登录已整体移除
    check(
        "配置默认值不含 lanzou_username",
        "lanzou_username" not in main._DEFAULT_CONFIG,
    )
    check(
        "配置默认值不含 lanzou_password",
        "lanzou_password" not in main._DEFAULT_CONFIG,
    )
    creds = inspect.signature(lanzou_store.LanzouClient.__init__).parameters
    check("LanzouClient 不再接受 username", "username" not in creds, f"{list(creds)}")
    check("LanzouClient 不再接受 password", "password" not in creds, f"{list(creds)}")

    uncfg, _ = make_plugin(lanzou_enabled=False)
    check("目录名默认显示「根目录」", uncfg._lanzou_folder_label() == "根目录")
    named, _ = make_plugin(lanzou_folder="我的文件")
    check("目录名可配置", named._lanzou_folder_label() == "我的文件")


async def test_file_map_cache() -> None:
    section("5. 蓝奏云清单缓存（TTL / 强制刷新 / 失败回退）")

    plugin, _ = make_plugin()
    fake = attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES))

    fmap = await plugin._lanzou_file_map()
    check("清单条数与文件数一致", len(fmap) == 3, f"{len(fmap)}")
    check("清单调用 1 次", fake.list_calls == 1, f"{fake.list_calls}")
    check(
        "归一化键可命中（空格差异）",
        file_utils.normalize_name("朗朗 晴天.zip") in fmap,
    )

    # TTL 内不应重复请求
    await plugin._lanzou_file_map()
    check("TTL 内命中缓存（未再次请求）", fake.list_calls == 1, f"{fake.list_calls}")

    # 手动把缓存时间戳推老 → 触发刷新
    plugin._lanzou_map_at = 0.0
    await plugin._lanzou_file_map()
    check("缓存过期后重新请求", fake.list_calls == 2, f"{fake.list_calls}")

    # 强制刷新
    await plugin._lanzou_file_map(force=True)
    check("force=True 强制请求", fake.list_calls == 3, f"{fake.list_calls}")

    # 失败回退旧缓存
    fake.fail_list = True
    plugin._lanzou_map_at = 0.0
    fallback = await plugin._lanzou_file_map()
    check("读取失败时回退旧缓存", len(fallback) == 3, f"{len(fallback)}")

    # 未配置 → 空表且不请求
    uncfg, _ = make_plugin(lanzou_enabled=False)
    uncfg_fake = attach_fake(uncfg, FakeLanzou(files=SAMPLE_FILES))
    empty = await uncfg._lanzou_file_map()
    check("未配置时返回空清单", empty == {})
    check("未配置时不请求客户端", uncfg_fake.list_calls == 0, f"{uncfg_fake.list_calls}")


async def test_share_cache() -> None:
    section("6. 分享链接按需取 + 缓存")

    plugin, _ = make_plugin()
    fake = attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))

    share = await plugin._lanzou_share(111)
    check("取到链接", bool(share and share.get("url")))
    check("取到提取码", share.get("pwd") == "ab11", f"{share.get('pwd')}")
    await plugin._lanzou_share(111)
    check("分享链接命中缓存", fake.share_calls == [111], f"{fake.share_calls}")

    missing = await plugin._lanzou_share(999)
    check("无对应分享信息返回 None", missing is None)

    # 强制刷新清单会顺带失效分享缓存
    await plugin._lanzou_file_map(force=True)
    await plugin._lanzou_share(111)
    check("强制刷新后分享缓存被清空并重取", fake.share_calls == [111, 999, 111], f"{fake.share_calls}")


async def test_search_entries() -> None:
    section("7. 清单内模糊搜索 / 定位")

    plugin, _ = make_plugin()
    attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))
    fmap = await plugin._lanzou_file_map()

    all_hits = plugin._lanzou_search_entries(fmap, "")
    check("空关键词 = 全部", len(all_hits) == 3, f"{len(all_hits)}")
    check("按时间倒序（最新在前）", all_hits[0]["fid"] == 222, f"{all_hits[0]['fid']}")

    hits = plugin._lanzou_search_entries(fmap, "晴天")
    check("子串命中 2 个", len(hits) == 2, f"{len(hits)}")

    normalized = plugin._lanzou_search_entries(fmap, "朗朗晴天")
    check("归一化命中（忽略空格）", len(normalized) == 2, f"{len(normalized)}")

    none_hits = plugin._lanzou_search_entries(fmap, "不存在的名字")
    check("无匹配返回空", none_hits == [])

    # 定位：数字 ID / 精确名 / 归一化名 / 唯一模糊
    eid = plugin._lanzou_entry_id(222)
    check("按数字ID定位", (plugin._lanzou_find_entry(fmap, eid) or {}).get("fid") == 222)
    check("按精确名定位", (plugin._lanzou_find_entry(fmap, "报告2024.pdf") or {}).get("fid") == 222)
    check(
        "按归一化名定位",
        (plugin._lanzou_find_entry(fmap, "朗朗晴天.zip") or {}).get("fid") == 111,
    )
    check("不存在的引用返回 None", plugin._lanzou_find_entry(fmap, "没有这个") is None)
    check("空引用返回 None", plugin._lanzou_find_entry(fmap, "  ") is None)

    check("entry_id 由 fid 派生且稳定", plugin._lanzou_entry_id(111) == file_utils.numeric_id("lz_111"))


async def test_file_command_search() -> None:
    section("8. /file list | search | download")

    plugin, _ = make_plugin()
    attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))

    # help（私聊也可用）
    help_event = make_command_event("file help", private=True)
    help_out = joined(await run_command(plugin, help_event, "file help"))
    check("help 含用法", "file search" in help_out and "file download" in help_out)

    # list（列出全部）
    ev = make_command_event("file list")
    out = joined(await run_command(plugin, ev, "file list"))
    check("list 列出 3 个文件", "共 3 个文件" in out, out.splitlines()[-1] if out else "")
    check("list 含数字文件ID", "文件ID：" in out)

    # search
    ev = make_command_event("file search 晴天")
    out = joined(await run_command(plugin, ev, "file search 晴天"))
    check("search 命中 2 个", "共 搜索到 2 个文件" in out, out)
    check("search 标题正确", "🔍 搜索「晴天」" in out)

    # search 无结果
    ev = make_command_event("file search 不存在")
    out = joined(await run_command(plugin, ev, "file search 不存在"))
    check("search 无结果提示", "没有找到包含「不存在」" in out, out)

    # search 缺参数
    ev = make_command_event("file search")
    out = joined(await run_command(plugin, ev, "file search"))
    check("search 缺参提示用法", "用法：/file search" in out, out)

    # download 按数字 ID
    ev = make_command_event("file download 222")
    out = joined(await run_command(plugin, ev, "file download 222"))
    # 注：222 不是派生 ID，这里应走「按文件名」失败；改用它自己的派生 ID 再试
    eid = plugin._lanzou_entry_id(222)
    ev = make_command_event(f"file download {eid}")
    out = joined(await run_command(plugin, ev, f"file download {eid}"))
    check("download 卡片含链接", "链接：https://wwx.lanzou.com/iABC222" in out, out)
    check("download 卡片含提取码", "提取码：无" in out, out)
    check("download 卡片标注存储位置", "存储位置：蓝奏网盘" in out, out)
    check("download 卡片有效期为永久", "有效期：永久" in out, out)
    check("download 不伪造短链接行", "短链接：" not in out, out)
    check("download 不伪造口令行", "口令：" not in out, out)

    # download 按文件名（含空格 → 验证 GreedyStr 贪婪）
    ev = make_command_event("file download 朗朗 晴天.zip")
    out = joined(await run_command(plugin, ev, "file download 朗朗 晴天.zip"))
    check("download 多词文件名（GreedyStr 生效）", "iABC111" in out, out)

    # download 找不到
    ev = make_command_event("file download 不存在的东西")
    out = joined(await run_command(plugin, ev, "file download 不存在的东西"))
    check("download 找不到提示", "没有找到「不存在的东西」" in out, out)

    # 未知子指令
    ev = make_command_event("file wat")
    out = joined(await run_command(plugin, ev, "file wat"))
    check("未知子指令给出帮助", "未知的子指令" in out, out)

    # 私聊限制
    ev = make_command_event("file list", private=True)
    out = joined(await run_command(plugin, ev, "file list"))
    check("私聊只能看帮助/受限", "只能在群聊中使用" in out, out)


async def test_file_command_refresh_and_unconfigured() -> None:
    section("9. /file lzrefresh 权限 + 未配置提示")

    plugin, _ = make_plugin()
    fake = attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))

    admin_ev = make_command_event("file lzrefresh", role="admin")
    out = joined(await run_command(plugin, admin_ev, "file lzrefresh"))
    check("管理员可刷新", "已刷新" in out, out)
    check("刷新确实重新请求", fake.list_calls >= 1)

    member_ev = make_command_event("file lzrefresh", role="member")
    out = joined(await run_command(plugin, member_ev, "file lzrefresh"))
    check("非管理员被拒绝", "只有管理员" in out, out)

    # 未启用蓝奏云时的搜索/下载提示
    uncfg, _ = make_plugin(lanzou_enabled=False)
    ev = make_command_event("file search 任意")
    out = joined(await run_command(uncfg, ev, "file search 任意"))
    check("未配置 search 提示启用", "未启用蓝奏云" in out, out)

    ev = make_command_event("file download 任意")
    out = joined(await run_command(uncfg, ev, "file download 任意"))
    check("未配置 download 提示启用", "未启用蓝奏云" in out, out)

    ev = make_command_event("file lzrefresh")
    out = joined(await run_command(uncfg, ev, "file lzrefresh"))
    check("未配置 lzrefresh 提示启用", "未启用蓝奏云" in out, out)


async def test_quick_commands() -> None:
    section("10. 快捷指令「搜索」「下载」")

    plugin, _ = make_plugin()
    attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))

    ev = make_command_event("搜索 晴天")
    out = joined(await run_quick(plugin, main.GroupFileManagerPlugin.quick_search_command, ev, "搜索 晴天"))
    check("快捷搜索命中", "共 搜索到 2 个文件" in out, out)

    eid = plugin._lanzou_entry_id(333)
    ev = make_command_event(f"下载 {eid}")
    out = joined(await run_quick(plugin, main.GroupFileManagerPlugin.quick_download_command, ev, f"下载 {eid}"))
    check("快捷下载给链接", "iABC333" in out, out)

    # 缺参数
    ev = make_command_event("搜索")
    out = joined(await run_quick(plugin, main.GroupFileManagerPlugin.quick_search_command, ev, "搜索"))
    check("快捷搜索缺参提示", "用法：搜索" in out, out)

    ev = make_command_event("下载")
    out = joined(await run_quick(plugin, main.GroupFileManagerPlugin.quick_download_command, ev, "下载"))
    check("快捷下载缺参提示", "用法：下载" in out, out)

    # 私聊静默（返回空）
    ev_priv = make_command_event("搜索 晴天", private=True)
    out = await run_quick(plugin, main.GroupFileManagerPlugin.quick_search_command, ev_priv, "搜索 晴天")
    check("私聊静默忽略", plain_texts(out) == [], f"{plain_texts(out)}")

    # 开关关闭 → 静默
    off, _ = make_plugin(quick_commands=False)
    attach_fake(off, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))
    ev = make_command_event("搜索 晴天")
    out = await run_quick(off, main.GroupFileManagerPlugin.quick_search_command, ev, "搜索 晴天")
    check("关闭快捷指令后静默", plain_texts(out) == [], f"{plain_texts(out)}")


def test_split_page() -> None:
    section("11. 分页解析 _split_page")

    split = main.GroupFileManagerPlugin._split_page
    check("尾部纯数字视为页码", split("晴天 2") == ("晴天", 2))
    check("无页码默认第 1 页", split("晴天") == ("晴天", 1))
    check("文件名含数字不误判", split("报告2024") == ("报告2024", 1))
    check("页码下限为 1", split("晴天 0") == ("晴天", 1))
    check("空串", split("") == ("", 1))


def test_detail_card_variants() -> None:
    section("12. 详情卡片：只展示蓝奏云真实字段")

    base = main.GroupFileManagerPlugin._lanzou_detail_card(
        "报告2024.pdf",
        "1.2 M",
        "123456789",
        {"url": "https://wwx.lanzou.com/iABC222", "pwd": ""},
    )
    check("首行是文件详情", base.startswith("📦 文件详情"), base.splitlines()[0])
    check("含链接", "链接：https://wwx.lanzou.com/iABC222" in base)
    check("提取码为空时显示「无」", "提取码：无" in base)
    check("不含短链接行", "短链接：" not in base)
    check("不含口令行", "口令：" not in base)

    # 只有当 share 真的带了不同短链接/口令时才追加
    rich = main.GroupFileManagerPlugin._lanzou_detail_card(
        "a.bin",
        "1 B",
        "1",
        {
            "url": "https://wwx.lanzou.com/long",
            "pwd": "x",
            "short_url": "https://wwx.lanzou.com/short",
            "command": "复制口令",
        },
    )
    check("真短链接才显示", "短链接：https://wwx.lanzou.com/short" in rich)
    check("真口令才显示", "口令：复制口令" in rich)

    # 短链接与主链接相同时不应重复展示
    same = main.GroupFileManagerPlugin._lanzou_detail_card(
        "b.bin",
        "1 B",
        "2",
        {"url": "https://wwx.lanzou.com/same", "pwd": "", "short_url": "https://wwx.lanzou.com/same"},
    )
    check("短链接与主链接相同则不重复", "短链接：" not in same)

    # _share_fields 同理
    fields = main.GroupFileManagerPlugin._share_fields(
        {"url": "https://x", "short_url": "https://x", "command": ""},
    )
    check("_share_fields 过滤相同/空值", fields == {}, f"{fields}")


async def test_web_api() -> None:
    section("13. Web API（overview / files / files-link / refresh）")

    plugin, ctx = make_plugin(lanzou_folder="我的文件")
    attach_fake(plugin, FakeLanzou(files=SAMPLE_FILES, shares=SAMPLE_SHARES))

    # 路由注册齐全
    registered = sorted(route for route, *_ in ctx.registered_web_apis)
    check(
        "注册了 4 个路由",
        registered
        == sorted(
            [
                f"/{main.PLUGIN_NAME}/overview",
                f"/{main.PLUGIN_NAME}/files",
                f"/{main.PLUGIN_NAME}/files/link",
                f"/{main.PLUGIN_NAME}/files/refresh",
            ],
        ),
        f"{registered}",
    )

    # overview
    resp = await call_api(plugin.api_overview)
    data = resp.json()
    check("overview configured", data.get("configured") is True, f"{data}")
    check("overview files 计数", data.get("files") == 3, f"{data.get('files')}")
    check("overview folder", data.get("folder") == "我的文件", f"{data.get('folder')}")
    check("overview cache_minutes", data.get("cache_minutes") == 30)

    # files（全部）
    resp = await call_api(plugin.api_files)
    data = resp.json()
    items = data.get("items", [])
    check("files 返回 3 条", len(items) == 3, f"{len(items)}")
    check("files total=3", data.get("total") == 3)
    check("files 条目带 id/name/size/time", all({"id", "name", "size_text", "time_text"} <= set(i) for i in items))
    check("files 条目存储位置为 lanzou", all(i["storage"] == "lanzou" for i in items))
    first = items[0]
    check("files 按时间倒序（最新在前）", first["name"] == "报告2024.pdf", f"{first['name']}")

    # files（关键词）
    resp = await call_api(plugin.api_files, [("keyword", "晴天")])
    data = resp.json()
    check("files 关键词过滤", len(data.get("items", [])) == 2, f"{data.get('total')}")

    # files（limit）
    resp = await call_api(plugin.api_files, [("limit", "1")])
    data = resp.json()
    check("files limit 生效", len(data.get("items", [])) == 1 and data.get("total") == 3, f"{data}")

    # files/link 成功
    eid = plugin._lanzou_entry_id(111)
    resp = await call_api(plugin.api_file_link, [("file_id", eid)])
    data = resp.json()
    check("link 返回链接", data.get("link") == "https://wwx.lanzou.com/iABC111", f"{data}")
    check("link 返回提取码", data.get("pwd") == "ab11")
    check("link 标注永久", data.get("permanent") is True)
    check("link 存储位置 lanzou", data.get("storage") == "lanzou")
    check("link 不含 short_url（蓝奏云没有）", "short_url" not in data, f"{data}")
    check("link 不含 command（蓝奏云没有）", "command" not in data, f"{data}")

    # files/link 缺参数
    resp = await call_api(plugin.api_file_link, [])
    check("link 缺 file_id → 400", resp.status_code == 400, f"{resp.status_code}")
    check("link 缺参错误信封", resp.json().get("status") == "error")

    # files/link 找不到
    resp = await call_api(plugin.api_file_link, [("file_id", "000000000")])
    check("link 找不到 → 404", resp.status_code == 404, f"{resp.status_code}")

    # files/refresh 成功
    resp = await call_api(plugin.api_refresh_files)
    data = resp.json()
    check("refresh 返回文件数", data.get("files") == 3, f"{data}")

    # 未配置的插件：files 返回空、link/refresh 报 409
    uncfg, _ = make_plugin(lanzou_enabled=False)
    resp = await call_api(uncfg.api_files)
    data = resp.json()
    check("未配置 files configured=False", data.get("configured") is False, f"{data}")
    check("未配置 files items 为空", data.get("items") == [])

    resp = await call_api(uncfg.api_file_link, [("file_id", "1")])
    check("未配置 link → 409", resp.status_code == 409, f"{resp.status_code}")

    resp = await call_api(uncfg.api_refresh_files)
    check("未配置 refresh → 409", resp.status_code == 409, f"{resp.status_code}")

    # 未配置的 overview
    resp = await call_api(uncfg.api_overview)
    data = resp.json()
    check("未配置 overview configured=False", data.get("configured") is False)


async def test_pages_assets_contract() -> None:
    section("14. 前端资源与前后端契约")

    page = _PLUGIN_ROOT / "pages" / "file-manager"
    html = (page / "index.html").read_text(encoding="utf-8")
    js = (page / "app.js").read_text(encoding="utf-8")
    css = (page / "style.css").read_text(encoding="utf-8")

    # 群文件相关内容必须从页面里消失
    for gone in ("select-group", "btn-import", "dialog-send", "dialog-rename", "btn-clear-group"):
        check(f"index.html 不含 {gone}", gone not in html)
    for gone in ("col-group", "col-uploader", "col-storage"):
        check(f"index.html 不含列 {gone}", gone not in html)

    # 前端不再调用群文件相关接口
    for gone in ("apiGet(\"groups\"", "files/send", "files/delete", "files/rename", "import/start"):
        check(f"app.js 不再调用 {gone}", gone not in js)

    # 引用的资源文件都存在
    for ref in ("./app.js", "./style.css"):
        check(f"index.html 引用 {ref}", ref in html)

    # 前后端 endpoint 契约：前端调用的 endpoint 必须在后端注册
    import re

    used = set(re.findall(r'bridge\.api(?:Get|Post)\(\s*"([^"]+)"', js))
    py_text = (_PLUGIN_ROOT / "main.py").read_text(encoding="utf-8")
    registered = set(
        hit.lstrip("/")
        for hit in re.findall(r'f"/\{PLUGIN_NAME\}([^"]*)"', py_text)
    )
    missing = sorted(e for e in used if e not in registered)
    check("前端 endpoint 均已注册", missing == [], f"缺失: {missing}")
    check("前端确实调用了接口", len(used) >= 3, f"{sorted(used)}")

    # 页面标题反映新定位
    check("页面标题为蓝奏云文件管理器", "蓝奏云文件管理器" in html)
    check("样式含网盘徽标", ".badge-netdisk" in css)


# ===========================================================================
# 主入口
# ===========================================================================
async def run_async_tests() -> None:
    await test_file_map_cache()
    await test_share_cache()
    await test_search_entries()
    await test_file_command_search()
    await test_file_command_refresh_and_unconfigured()
    await test_quick_commands()
    await test_web_api()
    await test_pages_assets_contract()


def main_entry() -> int:
    print("蓝奏云文件管理器 - 开发自测（只读链接提取）")

    test_no_group_file_layer()
    test_register_metadata()
    test_file_utils()
    test_lanzou_configured()
    test_split_page()
    test_detail_card_variants()

    asyncio.run(run_async_tests())

    print("\n" + "=" * 58)
    total = len(PASSED) + len(FAILED)
    if FAILED:
        print(f"失败 {len(FAILED)} / {total}：")
        for name, detail in FAILED:
            print(f"  * {name} :: {detail}")
    else:
        print(f"全部通过（{total} 项）")
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main_entry())
