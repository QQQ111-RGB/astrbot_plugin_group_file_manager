"""桩：astrbot.api.event.filter。

真实实现里 ``filter`` 是 ``astrbot/api/event/filter/`` 子包，
插件通过 ``from astrbot.api.event import filter`` 拿到它，然后使用
``filter.command`` / ``filter.event_message_type`` / ``filter.EventMessageType``。
"""

from __future__ import annotations

from . import astrbot_api_event as _event

# 直接复用事件桩里定义的装饰器与枚举
command = _event.command
command_group = _event.command_group
event_message_type = _event.event_message_type
permission_type = _event.permission_type
platform_adapter_type = _event.platform_adapter_type
regex = _event.regex
on_astrbot_loaded = _event.on_astrbot_loaded

EventMessageType = _event.EventMessageType
PermissionType = _event.PermissionType

# 记录注册情况的容器（测试断言用）
registered_handlers = _event.registered_handlers

__all__ = [
    "EventMessageType",
    "PermissionType",
    "command",
    "command_group",
    "event_message_type",
    "on_astrbot_loaded",
    "permission_type",
    "platform_adapter_type",
    "regex",
    "registered_handlers",
]
