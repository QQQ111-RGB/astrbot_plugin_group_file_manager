"""桩：astrbot.api.event —— filter / AstrMessageEvent / MessageChain。"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("astrbot")

# 记录被装饰器注册的 handler，供测试断言
registered_handlers: list[dict[str, Any]] = []


class EventMessageType(enum.Flag):
    GROUP_MESSAGE = enum.auto()
    PRIVATE_MESSAGE = enum.auto()
    OTHER_MESSAGE = enum.auto()
    ALL = GROUP_MESSAGE | PRIVATE_MESSAGE | OTHER_MESSAGE


class PermissionType(enum.Flag):
    ADMIN = enum.auto()
    ALL = enum.auto()


class _Filter:
    def __init__(self, **kwargs: Any) -> None:
        self.kwargs = kwargs


from .astrbot_core_star_filter_command import GreedyStr


def _parse_command_params(func, message_str: str) -> dict[str, Any] | None:
    """复刻 AstrBot ``CommandFilter.validate_and_convert_params`` 的行为。

    返回 None 表示「消息不是以该指令开头」。
    这样测试里 handler 收到的参数与真实 AstrBot 一致，从而能捕捉到
    「自行解析 event.message_str 而不用参数注入」这类真实 bug。
    """
    import inspect
    import re
    import types as _types
    import typing

    # 关键：main.py 使用 `from __future__ import annotations`，注解都是字符串，
    # 必须像 AstrBot 那样用 eval_str=True 求值，否则 GreedyStr 无法被识别。
    sig = inspect.signature(func, eval_str=True)
    handler_params: dict[str, Any] = {}
    for idx, (name, param) in enumerate(sig.parameters.items()):
        if idx < 2:  # 跳过 self 与 event
            continue
        handler_params[name] = (
            param.annotation
            if param.default is inspect.Parameter.empty
            else param.default
        )

    normalized = re.sub(r"\s+", " ", message_str.strip())
    names = [getattr(func, "_command_name", "")]
    names += sorted(getattr(func, "_command_alias", set()))
    matched = None
    for full_cmd in names:
        if not full_cmd:
            continue
        if normalized.startswith(f"{full_cmd} ") or normalized == full_cmd:
            matched = full_cmd
    if matched is None:
        return None

    remainder = normalized[len(matched) :].strip()
    ls = [p for p in remainder.split(" ") if p]

    result: dict[str, Any] = {}
    for i, (param_name, param_type) in enumerate(handler_params.items()):
        # 复刻 AstrBot 的判断顺序（CommandFilter.validate_and_convert_params）：
        #   1) is_greedy = (param_type_or_default_val is GreedyStr)  ← 同一性判断
        #   2) ... elif isinstance(param_type_or_default_val, str): 只取第一个词
        # 注意 param_type 可能是「注解」也可能是「默认值」，取决于 handler 有没有写默认值。
        # 默认值写 "" 或 GreedyStr() 都是 str 实例 → 会命中第 2 条 → 贪婪失效。
        # 这就是「file list 能过、file send 文件名 丢参数」的根因。
        if param_type is GreedyStr:
            result[param_name] = " ".join(ls[i:])
            break
        if param_type is None:
            if i < len(ls):
                result[param_name] = ls[i]
            continue
        if isinstance(param_type, str):
            if i < len(ls):
                result[param_name] = ls[i]
            continue
        if i >= len(ls):
            if isinstance(param_type, (type, _types.UnionType)) or typing.get_origin(
                param_type,
            ) is typing.Union:
                raise ValueError(f"必要参数缺失。该指令完整参数: {handler_params}")
            result[param_name] = param_type
            continue
        try:
            if isinstance(param_type, bool):
                result[param_name] = str(ls[i]).lower() in {"true", "yes", "1"}
            elif param_type is int:
                result[param_name] = int(ls[i])
            elif param_type is float:
                result[param_name] = float(ls[i])
            else:
                result[param_name] = param_type(ls[i])
        except (TypeError, ValueError) as exc:
            raise ValueError(f"参数 {param_name} 类型错误") from exc
    return result


async def call_handler(event: "AstrMessageEvent", handler, **params: Any):
    """复刻 AstrBot ``pipeline.context.call_handler``：把参数注入 handler。

    同时支持 async generator 与普通协程 handler。
    """
    import inspect

    result = handler(event, **params)
    if inspect.isasyncgen(result):
        async for item in result:
            yield item
    else:
        await result


def _record(kind: str, name: str, **kwargs: Any):
    def decorator(func):
        if kind == "command":
            func._command_name = name
            func._command_alias = kwargs.get("alias") or set()
        registered_handlers.append(
            {"kind": kind, "name": name, "func": func, **kwargs},
        )
        return func

    return decorator


def command(name: str, alias: set[str] | None = None, **kwargs: Any):
    return _record("command", name, alias=alias or set(), **kwargs)


def command_group(name: str, **kwargs: Any):
    return _record("command_group", name, **kwargs)


def event_message_type(message_type: Any, **kwargs: Any):
    return _record("event_message_type", str(message_type), **kwargs)


def permission_type(permission: Any, **kwargs: Any):
    return _record("permission_type", str(permission), **kwargs)


def platform_adapter_type(adapter_type: Any, **kwargs: Any):
    return _record("platform_adapter_type", str(adapter_type), **kwargs)


def regex(pattern: str, **kwargs: Any):
    return _record("regex", pattern, **kwargs)


def on_astrbot_loaded(**kwargs: Any):
    return _record("on_astrbot_loaded", "on_astrbot_loaded", **kwargs)


def on_plugin_loaded(**kwargs: Any):
    return _record("on_plugin_loaded", "on_plugin_loaded", **kwargs)


class MessageType(enum.Enum):
    GROUP_MESSAGE = "GroupMessage"
    FRIEND_MESSAGE = "FriendMessage"
    OTHER_MESSAGE = "OtherMessage"


@dataclass
class MessageMember:
    user_id: str = ""
    nickname: str = ""


@dataclass
class Group:
    group_id: str = ""
    group_name: str = ""


@dataclass
class AstrBotMessage:
    """对齐 astrbot.core.platform.astrbot_message.AstrBotMessage 的字段。"""

    type: MessageType = MessageType.GROUP_MESSAGE
    self_id: str = "10000"
    session_id: str = ""
    message_id: str = "msgid"
    group_id: str = ""
    sender: MessageMember = field(default_factory=MessageMember)
    message: list[Any] = field(default_factory=list)
    message_str: str = ""
    raw_message: Any = None
    timestamp: int = 0
    group: Group | None = None


class PlatformMetadata:
    def __init__(self, name: str, description: str = "", id: str = "") -> None:
        self.name = name
        self.description = description
        self.id = id or name


@dataclass
class MessageChain:
    chain: list[Any] = field(default_factory=list)
    use_t2i_: bool | None = None
    type: str | None = None


class MessageEventResult(MessageChain):
    pass


class AstrMessageEvent:
    """桩事件对象，实现插件实际用到的那些方法。"""

    def __init__(
        self,
        message_obj: AstrBotMessage,
        platform_meta: PlatformMetadata | None = None,
        session_id: str = "",
        *,
        message_str: str = "",
        role: str = "member",
    ) -> None:
        self.message_obj = message_obj
        self.platform_meta = platform_meta or PlatformMetadata("aiocqhttp", id="default")
        self.message_str = message_str or message_obj.message_str
        self.role = role
        self._session_id = session_id or message_obj.session_id
        self.sent: list[MessageChain] = []
        self._extras: dict[str, Any] = {}

    # --- 与真实实现一致的关键属性/方法 ---
    @property
    def unified_msg_origin(self) -> str:
        return f"{self.platform_meta.id}:{self.message_obj.type.value}:{self._session_id}"

    @property
    def session_id(self) -> str:
        return self._session_id

    def get_platform_name(self) -> str:
        return self.platform_meta.name

    def get_platform_id(self) -> str:
        return self.platform_meta.id

    def get_message_type(self) -> MessageType:
        return self.message_obj.type

    def get_session_id(self) -> str:
        return self._session_id

    def get_group_id(self) -> str:
        return self.message_obj.group_id

    def get_self_id(self) -> str:
        return self.message_obj.self_id

    def get_sender_id(self) -> str:
        return self.message_obj.sender.user_id

    def get_sender_name(self) -> str:
        return self.message_obj.sender.nickname

    def get_messages(self) -> list[Any]:
        return self.message_obj.message

    def set_extra(self, key: str, value: Any) -> None:
        self._extras[key] = value

    def get_extra(self, key: str | None = None, default: Any = None) -> Any:
        if key is None:
            return self._extras
        return self._extras.get(key, default)

    def clear_extra(self) -> None:
        self._extras.clear()

    def is_admin(self) -> bool:
        return self.role == "admin"

    async def get_group(self, group_id: str | None = None, **kwargs: Any):
        if self.message_obj.group is not None:
            return self.message_obj.group
        if not (group_id or self.message_obj.group_id):
            return None
        return Group(group_id=str(group_id or self.message_obj.group_id))

    # --- 结果构造 ---
    def plain_result(self, text: str) -> MessageEventResult:
        from .astrbot_api_message_components import Plain

        return MessageEventResult(chain=[Plain(text)])

    def chain_result(self, chain: list[Any]) -> MessageEventResult:
        return MessageEventResult(chain=chain)

    async def send(self, chain: MessageChain) -> None:
        self.sent.append(chain)
