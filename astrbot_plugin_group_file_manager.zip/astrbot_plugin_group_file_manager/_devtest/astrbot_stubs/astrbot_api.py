"""桩：astrbot.api（包）—— 对齐 astrbot/api/__init__.py 的常用导出。"""

from __future__ import annotations

from . import astrbot_api_event as _event

logger = _event.logger


class AstrBotConfig(dict):
    """对齐 astrbot.core.config.astrbot_config.AstrBotConfig（继承 dict）。"""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.config_path = ""

    def save_config(self) -> None:
        """真实实现会写回配置文件；桩里为空操作。"""
        return None


__all__ = ["AstrBotConfig", "logger"]
