"""桩：astrbot.api.message_components —— File / Plain。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Plain:
    text: str
    type: str = "Plain"


@dataclass
class File:
    """对齐 astrbot.core.message.components.File。

    真实实现使用 pydantic 且构造签名为 ``File(name, file="", url="")``，
    并把 ``file`` 存进 ``file_`` 字段、通过 property 暴露 ``file``。
    这里保持一致，确保插件的 ``File(file=..., name=...)`` 用法可验证。
    """

    name: str = ""
    file_: str = ""
    url: str = ""
    type: str = "File"
    extra: dict[str, Any] = field(default_factory=dict)

    def __init__(self, name: str, file: str = "", url: str = "") -> None:
        self.name = name
        self.file_ = file
        self.url = url
        self.type = "File"
        self.extra = {}

    @property
    def file(self) -> str:
        return self.file_

    @file.setter
    def file(self, value: str) -> None:
        if value.startswith(("http://", "https://")):
            self.url = value
        else:
            self.file_ = value
