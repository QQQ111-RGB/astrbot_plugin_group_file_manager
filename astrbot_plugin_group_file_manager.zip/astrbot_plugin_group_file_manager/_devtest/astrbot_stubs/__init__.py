"""开发自测桩（stub）：在本地没有安装 AstrBot 时模拟其最小 API 面。

**这个目录只用于开发期自测，不参与插件运行，可以安全删除。**

桩的实现严格对齐 AstrBot master 分支的真实行为（见 README 的「API 核实清单」），
目的不是替代 AstrBot，而是让 test_plugin.py 能真实跑通插件的业务逻辑。
"""

from .install import install_stubs

__all__ = ["install_stubs"]
