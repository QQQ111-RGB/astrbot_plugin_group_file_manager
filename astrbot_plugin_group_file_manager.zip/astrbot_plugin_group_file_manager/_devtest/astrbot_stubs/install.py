"""把 AstrBot 桩模块注册进 sys.modules。"""

from __future__ import annotations

import sys
import types

from . import astrbot_api_event, astrbot_api_message_components, astrbot_api_star
from . import astrbot_api_web, astrbot_core_utils_astrbot_path
from . import astrbot_api, astrbot_api_event_filter
from . import astrbot_core_utils_command_parser
from . import astrbot_core_star_filter_command


def install_stubs() -> None:
    """注册所有桩模块。重复调用是幂等的。"""
    if "astrbot" in sys.modules and getattr(
        sys.modules["astrbot"], "_devtest_stub", False
    ):
        return

    # ---- 顶层包 astrbot / astrbot.api / astrbot.core ... ---------------
    # 注意：这些桩必须是「包」（设置 __path__），否则
    # `from astrbot.api.event import ...` 会绕过 sys.modules 里注册的子模块。
    astrbot = types.ModuleType("astrbot")
    astrbot._devtest_stub = True
    astrbot.logger = astrbot_api_event.logger  # 与 astrbot.api.logger 同一对象
    astrbot.__path__ = []

    core = types.ModuleType("astrbot.core")
    core.__path__ = []
    core_utils = types.ModuleType("astrbot.core.utils")
    core_utils.__path__ = []
    core_star = types.ModuleType("astrbot.core.star")
    core_star.__path__ = []
    core_star_filter = types.ModuleType("astrbot.core.star.filter")
    core_star_filter.__path__ = []

    # `from astrbot.api.event import filter` 要求 astrbot.api.event 上有 filter 属性
    astrbot_api_event.filter = astrbot_api_event_filter

    astrbot_api.__path__ = []

    sys.modules["astrbot"] = astrbot
    sys.modules["astrbot.api"] = astrbot_api
    sys.modules["astrbot.core"] = core
    sys.modules["astrbot.core.utils"] = core_utils

    sys.modules["astrbot.api.event"] = astrbot_api_event
    sys.modules["astrbot.api.event.filter"] = astrbot_api_event_filter
    sys.modules["astrbot.api.message_components"] = astrbot_api_message_components
    sys.modules["astrbot.api.star"] = astrbot_api_star
    sys.modules["astrbot.api.web"] = astrbot_api_web
    sys.modules["astrbot.core.utils.astrbot_path"] = astrbot_core_utils_astrbot_path
    sys.modules["astrbot.core.utils.command_parser"] = (
        astrbot_core_utils_command_parser
    )
    sys.modules["astrbot.core.star"] = core_star
    sys.modules["astrbot.core.star.filter"] = core_star_filter
    sys.modules["astrbot.core.star.filter.command"] = astrbot_core_star_filter_command
