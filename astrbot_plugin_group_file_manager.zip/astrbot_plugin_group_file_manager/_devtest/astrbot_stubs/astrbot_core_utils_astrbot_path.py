"""桩：astrbot.core.utils.astrbot_path。

真实实现返回 ``<AstrBot root>/data/plugin_data``；测试里指向临时目录。
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

# 测试运行前可用环境变量 ASTRBOT_TEST_DATA 覆盖
_DEFAULT = Path(tempfile.gettempdir()) / "astrbot_devtest_data"


def get_astrbot_data_path() -> str:
    return str(Path(os.environ.get("ASTRBOT_TEST_DATA", _DEFAULT)))


def get_astrbot_plugin_data_path() -> str:
    return str(Path(get_astrbot_data_path()) / "plugin_data")


def get_astrbot_path() -> str:
    return str(Path(get_astrbot_data_path()).parent)


def get_astrbot_root() -> str:
    return str(Path(get_astrbot_data_path()).parent)


def get_astrbot_temp_path() -> str:
    return str(Path(get_astrbot_data_path()) / "temp")
