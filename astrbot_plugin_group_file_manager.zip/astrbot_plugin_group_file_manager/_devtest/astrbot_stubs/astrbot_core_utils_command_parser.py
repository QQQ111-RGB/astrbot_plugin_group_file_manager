"""桩：astrbot.core.utils.command_parser —— CommandParserMixin / CommandTokens。

对齐 AstrBot v4.27.4 的 ``astrbot/core/utils/command_parser.py``。

.. note::
   ``GreedyStr`` **不在**这个模块里（真实 AstrBot 也没有），
   它定义在 ``astrbot/core/star/filter/command.py``。
"""

from __future__ import annotations

import re


class CommandTokens:
    def __init__(self) -> None:
        self.tokens: list[str] = []
        self.len = 0

    def get(self, idx: int) -> str | None:
        if idx >= self.len:
            return None
        return self.tokens[idx].strip()


class CommandParserMixin:
    def parse_commands(self, message: str) -> CommandTokens:
        cmd_tokens = CommandTokens()
        cmd_tokens.tokens = re.split(r"\s+", message)
        cmd_tokens.len = len(cmd_tokens.tokens)
        return cmd_tokens
