"""桩：astrbot.api.star —— Star / Context / register。

Star 的 KV 行为对齐 astrbot.core.utils.plugin_kv_store.PluginKVStoreMixin，
Context 对齐 astrbot.core.star.context.Context（只实现插件用到的部分）。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class FakeKVStore:
    """内存 + 磁盘 KV，模拟 AstrBot 的 sp(plugin) 存储。"""

    def __init__(self) -> None:
        self._data: dict[str, Any] = {}

    async def put(self, key: str, value: Any) -> None:
        # 真实实现会把值 JSON 序列化后存库；这里做一次 round-trip 以暴露不可序列化问题
        self._data[key] = json.loads(json.dumps(value))

    async def get(self, key: str, default: Any) -> Any:
        return self._data.get(key, default)

    async def remove(self, key: str) -> None:
        self._data.pop(key, None)


KV = FakeKVStore()


class Star:
    """对齐 astrbot.core.star.base.Star。"""

    def __init__(self, context: "Context", config: dict | None = None) -> None:
        self.context = context
        import logging

        self.logger = logging.getLogger("astrbot.plugin.test")
        self.name = ""
        self.author = ""
        self.plugin_id = "test_author/test_plugin"

    async def put_kv_data(self, key: str, value: Any) -> None:
        await KV.put(key, value)

    async def get_kv_data(self, key: str, default: Any) -> Any:
        return await KV.get(key, default)

    async def delete_kv_data(self, key: str) -> None:
        await KV.remove(key)


class MessageSession:
    def __init__(self, platform_name: str, message_type: Any, session_id: str) -> None:
        self.platform_name = platform_name
        self.message_type = message_type
        self.session_id = session_id

    def __str__(self) -> str:
        value = getattr(self.message_type, "value", self.message_type)
        return f"{self.platform_name}:{value}:{self.session_id}"

    @staticmethod
    def from_str(text: str) -> "MessageSession":
        platform_id, message_type, session_id = text.split(":", 2)
        return MessageSession(platform_id, message_type, session_id)


class Context:
    """对齐 astrbot.core.star.context.Context（子集）。"""

    def __init__(self) -> None:
        self.registered_web_apis: list[tuple[str, Any, list[str], str]] = []
        self.sent_messages: list[tuple[str, Any]] = []
        # 可注入：模拟没有任何平台实例匹配
        self.platform_ids: list[str] = ["default"]

    def register_web_api(self, route, view_handler, methods, desc) -> None:
        for idx, api in enumerate(self.registered_web_apis):
            if api[0] == route and methods == api[2]:
                self.registered_web_apis[idx] = (route, view_handler, methods, desc)
                return
        self.registered_web_apis.append((route, view_handler, methods, desc))

    async def send_message(self, session, message_chain) -> bool:
        session_str = str(session)
        platform_id = session_str.split(":", 1)[0]
        if platform_id not in self.platform_ids:
            return False
        self.sent_messages.append((session_str, message_chain))
        return True

    def get_all_stars(self) -> list:
        return []


def register(*args: Any, **kwargs: Any):
    """对齐 astrbot.api.star.register（即 register_star）。"""

    def decorator(cls):
        cls._register_args = args
        cls._register_kwargs = kwargs
        return cls

    return decorator


# astrbot.api.star 里还导出了 StarTools，插件未使用，这里给出占位
class StarTools:
    @staticmethod
    def get_data_path(plugin_name: str) -> Path:
        return Path(".")
