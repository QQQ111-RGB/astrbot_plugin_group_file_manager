"""桩：astrbot.api.web —— request / json_response / error_response / file_response。

对齐 astrbot/api/web.py：json_response 返回普通 JSON；error_response 返回
``{"status": "error", "message": ...}`` 信封（bridge 会据此 reject）。
"""

from __future__ import annotations

import contextvars
import json
from typing import Any


class _Response:
    def __init__(self, payload: Any, status_code: int = 200) -> None:
        self.payload = payload
        self.status_code = status_code

    def json(self) -> Any:
        return json.loads(json.dumps(self.payload))

    def __repr__(self) -> str:
        return f"<Response {self.status_code} {self.payload!r}>"


class _MultiDict:
    def __init__(self, pairs: list[tuple[str, Any]]) -> None:
        self._pairs = pairs

    def get(self, key: str, default: Any = None, type: Any = None) -> Any:
        for item_key, item_value in reversed(self._pairs):
            if item_key != key:
                continue
            if type is None:
                return item_value
            try:
                return type(item_value)
            except (TypeError, ValueError):
                return default
        return default

    def getlist(self, key: str) -> list[Any]:
        return [v for k, v in self._pairs if k == key]

    def __contains__(self, key: str) -> bool:
        return any(k == key for k, _ in self._pairs)


class _Request:
    def __init__(self) -> None:
        self.query: _MultiDict = _MultiDict([])
        self.method = "GET"
        self.path = "/"
        self.plugin_name: str | None = None
        self.username: str | None = None
        self.path_params: dict[str, Any] = {}
        self._json: Any = {}
        self._form: _MultiDict = _MultiDict([])
        self._files: _MultiDict = _MultiDict([])

    async def json(self, default: Any = None) -> Any:
        return self._json if self._json is not None else default

    async def form(self) -> _MultiDict:
        return self._form

    async def files(self) -> _MultiDict:
        return self._files

    async def body(self) -> bytes:
        return b""


_request_var: contextvars.ContextVar[_Request] = contextvars.ContextVar("stub_request")


class _RequestProxy:
    def _get(self) -> _Request:
        try:
            return _request_var.get()
        except LookupError as exc:  # pragma: no cover - 仅在误用时触发
            raise RuntimeError(
                "astrbot.api.web.request is only available inside a plugin Web API handler.",
            ) from exc

    def __getattr__(self, key: str) -> Any:
        return getattr(self._get(), key)


request = _RequestProxy()


def set_request(req: _Request):
    """测试辅助：在调用 handler 前绑定一个请求上下文。"""
    return _request_var.set(req)


def reset_request(token) -> None:
    _request_var.reset(token)


def json_response(data: Any = None, *, status_code: int = 200, headers=None) -> _Response:
    return _Response({} if data is None else data, status_code)


def error_response(
    message: str,
    *,
    status_code: int = 400,
    data: Any = None,
    headers=None,
) -> _Response:
    return _Response(
        {"status": "error", "message": message, "data": data},
        status_code,
    )


def file_response(path, **kwargs) -> _Response:
    return _Response({"file": str(path), **kwargs}, 200)


def stream_response(content, **kwargs) -> _Response:
    return _Response({"stream": True}, 200)
