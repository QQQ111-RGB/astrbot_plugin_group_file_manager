"""桩：astrbot.core.star.filter.command。

真实 AstrBot 把 ``GreedyStr`` 定义在 ``astrbot/core/star/filter/command.py``，
插件通过 ``from astrbot.core.star.filter.command import GreedyStr`` 导入。

注意：**不要**从 ``astrbot.core.utils.command_parser`` 导入它——
那个模块只有 ``CommandParserMixin`` / ``CommandTokens``，没有 ``GreedyStr``。
"""

from __future__ import annotations


class GreedyStr(str):
    """标记指令完成其他参数接收后的所有剩余文本。

    必须是**类**（用作类型注解），默认值要写 ``GreedyStr()``。
    """
