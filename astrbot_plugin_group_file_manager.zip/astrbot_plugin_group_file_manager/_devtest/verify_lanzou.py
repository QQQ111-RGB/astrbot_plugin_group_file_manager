"""蓝奏云凭据验证脚本（只读模式）：登录 → 列目录 → 取分享链接。

凭据通过环境变量 LZ_YLOGIN / LZ_PHPDISK 传入，不落盘。
运行方式（插件目录下）::

    set LZ_YLOGIN=xxx && set LZ_PHPDISK=yyy && python _devtest/verify_lanzou.py
"""

import asyncio
import os
import sys
from pathlib import Path

# 安装 AstrBot 桩（lanzou_store 依赖 astrbot.api.logger）
_PLUGIN_ROOT = Path(__file__).resolve().parent.parent
_PARENT = _PLUGIN_ROOT.parent
for _p in (str(_PARENT), str(_PLUGIN_ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from _devtest.astrbot_stubs import install_stubs  # noqa: E402

install_stubs()

from astrbot_plugin_group_file_manager.lanzou_store import (  # noqa: E402
    LanzouClient,
    LanzouError,
)


async def main() -> int:
    ylogin = os.environ.get("LZ_YLOGIN", "").strip()
    phpdisk = os.environ.get("LZ_PHPDISK", "").strip()
    if not ylogin or not phpdisk:
        print("请先设置环境变量 LZ_YLOGIN / LZ_PHPDISK")
        return 1

    client = LanzouClient(
        cookie_ylogin=ylogin,
        cookie_phpdisk_info=phpdisk,
        folder_name="",  # 留空 = 读取蓝奏云根目录（与插件默认一致）
    )
    try:
        files = await client.list_files(recursive=True)
    except LanzouError as exc:
        print(f"LOGIN/LIST FAILED: {exc}")
        return 1

    print(f"LOGIN OK，蓝奏云根目录（含子目录）共 {len(files)} 个文件：")
    for item in files[:20]:
        print(f"  - fid={item['fid']} {item['name']}")

    if files:
        first = files[0]
        try:
            info = await client.share_info(first["fid"])
        except LanzouError as exc:
            print(f"SHARE FAILED: {exc}")
            return 1
        print("\n第一个文件的分享信息：")
        print("  url:", info["url"])
        print("  pwd:", repr(info["pwd"]))
        print("  name:", info["name"])
    else:
        print("\n目录为空：把你上传的文件放进蓝奏云后即可被机器人匹配。")
    print("\nDONE")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
